﻿namespace GaushalaAPI.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}