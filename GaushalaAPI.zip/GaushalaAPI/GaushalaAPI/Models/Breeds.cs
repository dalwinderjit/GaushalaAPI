﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GaushalAPI.Models
{
    public class Breeds
    {
        public int? Id;
        public string? Breed;
        
    }
}
