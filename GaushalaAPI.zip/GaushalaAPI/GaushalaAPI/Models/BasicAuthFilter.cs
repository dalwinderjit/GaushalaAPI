﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace GaushalAPI.Models
{
    public class BasicAuthFilter
    {

    }
}
