# GaushalaAPI
These are the APIs For gaushala project
#I have used Visual Studio 2019
#Sql server Management Studio v18.12
